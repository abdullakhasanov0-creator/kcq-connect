package com.kcqconnect.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

@Composable
fun KcqRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    Scaffold(
        bottomBar = {
            if (route == "home" || route == "diag") {
                NavigationBar(containerColor = Graphite) {
                    val colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Cyan,
                        selectedTextColor = Cyan,
                        indicatorColor = GraphiteLight
                    )
                    NavigationBarItem(
                        selected = route == "home",
                        onClick = { navigateTab(nav, "home") },
                        icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        label = { Text("Главная") },
                        colors = colors
                    )
                    NavigationBarItem(
                        selected = route == "diag",
                        onClick = { navigateTab(nav, "diag") },
                        icon = { Icon(Icons.Filled.Info, contentDescription = null) },
                        label = { Text("Диагностика") },
                        colors = colors
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(vm, onScan = { nav.navigate("scan") }) }
            composable("diag") { DiagnosticsScreen(vm) }
            composable("scan") {
                ScannerScreen(
                    vm,
                    onBack = { nav.popBackStack() },
                    onConnectStarted = { nav.popBackStack() }
                )
            }
        }
    }
}

private fun navigateTab(nav: androidx.navigation.NavController, route: String) {
    nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
