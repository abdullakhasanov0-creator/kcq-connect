package com.kcqconnect.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.kcqconnect.app.bluetooth.ScannedDevice

@Composable
fun ScannerScreen(vm: MainViewModel, onBack: () -> Unit, onConnectStarted: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val devices by vm.scanner.devices.collectAsState()
    val scanning by vm.scanner.scanning.collectAsState()
    val scanError by vm.scanner.error.collectAsState()
    val btOn by vm.btMonitor.enabled.collectAsState()

    var hasPerm by remember { mutableStateOf(context.hasBlePermissions()) }
    var denied by remember { mutableStateOf(false) }
    var showUnnamed by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        hasPerm = res.values.all { it }
        denied = !hasPerm
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasPerm = context.hasBlePermissions()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasPerm, btOn) {
        if (hasPerm && btOn) vm.scanner.start()
    }
    DisposableEffect(Unit) {
        onDispose { vm.scanner.stop() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Назад", color = Cyan) }
            Spacer(Modifier.width(8.dp))
            Text("Поиск самоката", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        when {
            !hasPerm -> InfoBlock(
                title = "Нужно разрешение",
                text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                    "Чтобы найти самокат, Android требует разрешение «Устройства поблизости» (Bluetooth). Оно используется только для поиска и подключения к самокату."
                else
                    "Android 8–11 требует разрешение на геолокацию для поиска Bluetooth-устройств. Приложение не определяет и не сохраняет ваше местоположение.",
                primaryLabel = if (denied) "Запросить снова" else "Разрешить",
                onPrimary = { launcher.launch(requiredBlePermissions()) },
                secondaryLabel = if (denied) "Открыть настройки приложения" else null,
                onSecondary = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    )
                }
            )
            !btOn -> InfoBlock(
                title = "Bluetooth выключен",
                text = "Включите Bluetooth, поиск начнётся автоматически.",
                primaryLabel = "Открыть настройки Bluetooth",
                onPrimary = { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
                secondaryLabel = null,
                onSecondary = {}
            )
            else -> {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { if (scanning) vm.scanner.stop() else vm.scanner.start() },
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = androidx.compose.ui.graphics.Color.Black)
                    ) { Text(if (scanning) "Остановить" else "Искать снова") }
                    if (scanning) CircularProgressIndicator(Modifier.size(22.dp), color = Cyan, strokeWidth = 2.dp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = showUnnamed, onCheckedChange = { showUnnamed = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Показывать устройства без имени", fontSize = 14.sp)
                }
                if (scanError != null) Text(scanError ?: "", color = Bad)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Text(
                        "Если список пуст: на Android 8–11 для поиска должна быть включена геолокация телефона.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                val shown = devices.filter { showUnnamed || it.name != null }
                if (shown.isEmpty()) {
                    Text(
                        if (scanning) "Ищем устройства…" else "Ничего не найдено. Включите самокат и повторите поиск.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.address }) { d ->
                        DeviceRow(d) {
                            vm.connect(d)
                            onConnectStarted()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceRow(d: ScannedDevice, onConnect: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Graphite),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(d.name ?: "Без имени", fontWeight = FontWeight.SemiBold)
                Text(d.address, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Сигнал: ${d.rssi} дБм", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(
                onClick = onConnect,
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = androidx.compose.ui.graphics.Color.Black)
            ) { Text("Подключить") }
        }
    }
}

@Composable
private fun InfoBlock(
    title: String,
    text: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    secondaryLabel: String?,
    onSecondary: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Graphite), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = onPrimary,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = androidx.compose.ui.graphics.Color.Black)
            ) { Text(primaryLabel) }
            if (secondaryLabel != null) {
                OutlinedButton(onClick = onSecondary, modifier = Modifier.fillMaxWidth()) { Text(secondaryLabel) }
            }
        }
    }
}
