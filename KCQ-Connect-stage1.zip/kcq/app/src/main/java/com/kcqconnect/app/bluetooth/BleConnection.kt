package com.kcqconnect.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothDevice
import android.content.Context
import com.kcqconnect.app.diagnostics.DiagnosticsLog
import com.kcqconnect.app.protocol.AdapterRegistry
import com.kcqconnect.app.protocol.DecodeResult
import com.kcqconnect.app.protocol.ScooterAdapter
import com.kcqconnect.app.protocol.Telemetry
import com.kcqconnect.app.protocol.toHex
import com.kcqconnect.app.protocol.uuid16
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ConnectionState { DISCONNECTED, CONNECTING, DISCOVERING, CONNECTED, ERROR }

data class CharInfo(
    val uuid: String,
    val canRead: Boolean,
    val canWrite: Boolean,
    val canNotify: Boolean,
    val canIndicate: Boolean
)

data class ServiceInfo(val uuid: String, val characteristics: List<CharInfo>)

/**
 * Подключение к самокату по BLE.
 * Только чтение: единственная запись — включение уведомлений (CCCD) на характеристике адаптера.
 * Никаких команд управления самокатом не отправляется.
 */
@Suppress("DEPRECATION")
class BleConnection(
    private val context: Context,
    private val adapterProvider: () -> BluetoothAdapter?,
    private val log: DiagnosticsLog,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _deviceName = MutableStateFlow<String?>(null)
    val deviceName: StateFlow<String?> = _deviceName.asStateFlow()
    private val _address = MutableStateFlow<String?>(null)
    val address: StateFlow<String?> = _address.asStateFlow()
    private val _lastAddress = MutableStateFlow<String?>(null)
    val lastAddress: StateFlow<String?> = _lastAddress.asStateFlow()
    private val _services = MutableStateFlow<List<ServiceInfo>>(emptyList())
    val services: StateFlow<List<ServiceInfo>> = _services.asStateFlow()
    private val _telemetry = MutableStateFlow<Telemetry?>(null)
    val telemetry: StateFlow<Telemetry?> = _telemetry.asStateFlow()
    private val _lastRaw = MutableStateFlow<String?>(null)
    val lastRaw: StateFlow<String?> = _lastRaw.asStateFlow()
    private val _lastDataTime = MutableStateFlow<Long?>(null)
    val lastDataTime: StateFlow<Long?> = _lastDataTime.asStateFlow()
    private val _adapterName = MutableStateFlow<String?>(null)
    val adapterName: StateFlow<String?> = _adapterName.asStateFlow()
    private val _packetCount = MutableStateFlow(0)
    val packetCount: StateFlow<Int> = _packetCount.asStateFlow()

    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var activeAdapter: ScooterAdapter? = null
    @Volatile private var active = false
    @Volatile private var userDisconnect = false
    private var lastName: String? = null
    private var timeoutJob: Job? = null
    private var lastDecodeLogMs = 0L

    private val cccd: UUID = uuid16(0x2902)

    private fun resetData() {
        _services.value = emptyList()
        _telemetry.value = null
        _lastRaw.value = null
        _lastDataTime.value = null
        _adapterName.value = null
        _packetCount.value = 0
        activeAdapter = null
    }

    @SuppressLint("MissingPermission")
    fun connect(address: String, name: String?) {
        val st = _state.value
        if (st == ConnectionState.CONNECTING || st == ConnectionState.DISCOVERING || st == ConnectionState.CONNECTED) {
            log.add("WARN", "Подключение уже выполняется или установлено")
            return
        }
        val adapter = adapterProvider()
        if (adapter == null || !adapter.isEnabled) {
            fail("Bluetooth выключен")
            return
        }
        val device: BluetoothDevice = try {
            adapter.getRemoteDevice(address)
        } catch (e: IllegalArgumentException) {
            fail("Неверный адрес устройства")
            return
        }
        resetData()
        userDisconnect = false
        active = true
        lastName = name
        _deviceName.value = name
        _address.value = address
        _lastAddress.value = address
        _error.value = null
        _state.value = ConnectionState.CONNECTING
        log.add("INFO", "Подключение к ${name ?: "без имени"} ($address)")
        try {
            gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            fail("Нет разрешения BLUETOOTH_CONNECT")
            return
        } catch (e: Exception) {
            fail("Ошибка подключения: ${e.message}")
            return
        }
        timeoutJob?.cancel()
        timeoutJob = scope.launch {
            delay(CONNECT_TIMEOUT_MS)
            val s = _state.value
            if (s == ConnectionState.CONNECTING || s == ConnectionState.DISCOVERING) {
                fail("Тайм-аут подключения (${CONNECT_TIMEOUT_MS / 1000} с)")
            }
        }
    }

    fun reconnect() {
        val a = _lastAddress.value
        if (a == null) {
            log.add("WARN", "Нет сохранённого адреса для переподключения")
            return
        }
        connect(a, lastName)
    }

    fun disconnect() {
        userDisconnect = true
        log.add("INFO", "Отключение по запросу пользователя")
        closeGatt()
        _telemetry.value = null
        _state.value = ConnectionState.DISCONNECTED
    }

    fun release() {
        closeGatt()
    }

    private fun fail(message: String) {
        log.add("ERROR", message)
        _error.value = message
        closeGatt()
        _telemetry.value = null
        _state.value = ConnectionState.ERROR
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        active = false
        timeoutJob?.cancel()
        timeoutJob = null
        val g = gatt
        gatt = null
        activeAdapter = null
        try {
            g?.disconnect()
        } catch (e: Exception) {
        }
        try {
            g?.close()
        } catch (e: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableNotifications(g: BluetoothGatt, adapter: ScooterAdapter) {
        val ch = g.getService(adapter.serviceUuid)?.getCharacteristic(adapter.notifyUuid)
        if (ch == null) {
            log.add("WARN", "Характеристика уведомлений не найдена")
            return
        }
        val props = ch.properties
        val value = when {
            props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 -> BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0 -> BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            else -> null
        }
        if (value == null) {
            log.add("WARN", "Характеристика не поддерживает уведомления")
            return
        }
        try {
            g.setCharacteristicNotification(ch, true)
            val d = ch.getDescriptor(cccd)
            if (d == null) {
                log.add("WARN", "Нет дескриптора 2902 у характеристики уведомлений")
                return
            }
            d.value = value
            val ok = g.writeDescriptor(d)
            log.add("INFO", "Включение уведомлений: запрос ${if (ok) "отправлен" else "не отправлен"}")
        } catch (e: SecurityException) {
            fail("Нет разрешения BLUETOOTH_CONNECT")
        }
    }

    private fun handleData(uuid: UUID, bytes: ByteArray) {
        try {
            val adapter = activeAdapter ?: return
            if (uuid != adapter.notifyUuid) return
            val count = _packetCount.updateAndGetCompat()
            val hex = bytes.toHex()
            _lastRaw.value = hex
            _lastDataTime.value = System.currentTimeMillis()
            if (count <= 3) log.add("INFO", "Пакет #$count: $hex")
            when (val r = adapter.decode(bytes)) {
                is DecodeResult.Ok -> _telemetry.value = r.telemetry
                is DecodeResult.Ignored -> logThrottled("INFO", r.reason)
                is DecodeResult.Error -> logThrottled("ERROR", r.reason)
            }
        } catch (e: Exception) {
            log.add("ERROR", "Ошибка обработки пакета: ${e.message}")
        }
    }

    private fun MutableStateFlow<Int>.updateAndGetCompat(): Int {
        update { it + 1 }
        return value
    }

    private fun logThrottled(level: String, msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastDecodeLogMs > 3000) {
            lastDecodeLogMs = now
            log.add(level, msg)
        }
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (!active) return
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                log.add("INFO", "Соединение установлено, поиск сервисов")
                _state.value = ConnectionState.DISCOVERING
                try {
                    if (!g.discoverServices()) fail("Не удалось начать поиск сервисов")
                } catch (e: SecurityException) {
                    fail("Нет разрешения BLUETOOTH_CONNECT")
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (userDisconnect) return
                fail("Соединение потеряно или не установлено (код $status)")
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                fail("Ошибка соединения (код $status)")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (!active) return
            if (status != BluetoothGatt.GATT_SUCCESS) {
                fail("Ошибка поиска сервисов (код $status)")
                return
            }
            val list = g.services.map { s ->
                ServiceInfo(
                    s.uuid.toString(),
                    s.characteristics.map { c ->
                        val p = c.properties
                        CharInfo(
                            uuid = c.uuid.toString(),
                            canRead = (p and BluetoothGattCharacteristic.PROPERTY_READ) != 0,
                            canWrite = (p and (BluetoothGattCharacteristic.PROPERTY_WRITE or
                                BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0,
                            canNotify = (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0,
                            canIndicate = (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                        )
                    }
                )
            }
            _services.value = list
            log.add("INFO", "Найдено сервисов: ${list.size}")
            timeoutJob?.cancel()
            val adapter = AdapterRegistry.all.firstOrNull { a ->
                g.getService(a.serviceUuid)?.getCharacteristic(a.notifyUuid) != null
            }
            _state.value = ConnectionState.CONNECTED
            if (adapter == null) {
                log.add("WARN", "Протокол не распознан — диагностический режим")
                return
            }
            activeAdapter = adapter
            _adapterName.value = adapter.displayName
            log.add("INFO", "Выбран адаптер: ${adapter.displayName}")
            enableNotifications(g, adapter)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            if (!active) return
            if (status == BluetoothGatt.GATT_SUCCESS) {
                log.add("INFO", "Уведомления включены")
            } else {
                log.add("ERROR", "Не удалось включить уведомления (код $status)")
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value
            if (v != null) handleData(c.uuid, v)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            c: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleData(c.uuid, value)
        }
    }

    private companion object {
        const val CONNECT_TIMEOUT_MS = 15_000L
    }
}
