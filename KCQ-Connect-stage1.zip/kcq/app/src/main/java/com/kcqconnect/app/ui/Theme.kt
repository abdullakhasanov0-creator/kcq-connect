package com.kcqconnect.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF00D4FF)
val Graphite = Color(0xFF161A20)
val GraphiteLight = Color(0xFF232932)
val Ok = Color(0xFF35D07F)
val Warn = Color(0xFFFFB84D)
val Bad = Color(0xFFFF5C5C)

private val Scheme = darkColorScheme(
    primary = Cyan,
    onPrimary = Color.Black,
    background = Color(0xFF0B0D10),
    onBackground = Color(0xFFF2F5F7),
    surface = Graphite,
    onSurface = Color(0xFFF2F5F7),
    surfaceVariant = GraphiteLight,
    onSurfaceVariant = Color(0xFF9AA5B1),
    secondary = Cyan,
    error = Bad
)

@Composable
fun KcqTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
